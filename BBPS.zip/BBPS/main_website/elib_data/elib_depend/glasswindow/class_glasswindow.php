<?php
define("_DIR_GRAPH", "graphics/");
//template page
class gw_mainpageTemplate{

    public $PageProperties= null;
    public $HeadProperties= null;
    public $BodyProperties= null;
    public $FooterProperties= null;

public function __construct(){
}
    
   
    public function to($end="1"){
        if(empty($this->PageProperties)){
            $this->PageProperties = array(
                "bg"=>"linear-gradient(135deg, rgba(33,175,97,1) 0%,rgba(103,37,196,1) 100%)",
                "pageBg"=>"rgba(255,255,255,0.6)",
                "pageBorderRadius"=>"1px",
                "minHeight"=>"1000px",
                "title"=>"Digital Library",
                "doctype"=>"html",
                "baselan"=>"en-US",
                "charset"=>"utf-8",
                "keywords"=>"Bal Bharati Public School, Elibrary, Students Portal, Ncert Books, Ncert Solutions, Assignments, Sample Papers, Old Question Papers, Bal Bharati Public School Ganga Ram Hospital Marg, BBPS, BBPSGRHM, Learn, exercise, skill, education, practice",
                "description"=>"Learn, Practice, and Play at Bal Bharati Public School GRHM Student\'s Portal. Read books, view Ncert answers with solutions, discuss problems on school forum, solve online assignmets, see previous year question papers and more."
            );
        }
        else{
            if(empty($this->PageProperties["bg"])){
                $this->PageProperties["bg"]="linear-gradient(135deg, rgba(33,175,97,1) 0%,rgba(103,37,196,1) 100%)";
            }
            if(empty($this->PageProperties["pageBg"])){
                $this->PageProperties["pageBg"]="rgba(255,255,255,0.6)";
            }
            if(empty($this->PageProperties["pageBorderRadius"])){
                $this->PageProperties["pageBorderRadius"]="1px";
            }
            if(empty($this->PageProperties["minHeight"])){
                $this->PageProperties["minHeight"]="1000px";
            }
            if(empty($this->PageProperties["title"])){
                $this->PageProperties["title"]="Digital Library";
            }
            if(empty($this->PageProperties["doctype"])){
                $this->PageProperties["doctype"]="html";
            }
            if(empty($this->PageProperties["baselan"])){
                $this->PageProperties["baselan"]="en-US";
            }
            if(empty($this->PageProperties["charset"])){
                $this->PageProperties["charset"]="utf-8";
            }
            if(empty($this->PageProperties["keywords"])){
                $this->PageProperties["keywords"]="Bal Bharati Public School, Elibrary, Students Portal, Ncert Books, Ncert Solutions, Assignments, Sample Papers, Old Question Papers, Bal Bharati Public School Ganga Ram Hospital Marg, BBPS, BBPSGRHM, Learn, exercise, skill, education, practice";
            }
            if(empty($this->PageProperties["description"])){
                $this->PageProperties["description"]="Learn, Practice, and Play at Bal Bharati Public School GRHM Student\'s Portal. Read books, view Ncert answers with solutions, discuss problems on school forum, solve online assignmets, see previous year question papers and more.";
            }
        }
        if(empty($this->HeadProperties)){
            $this->HeadProperties = array(
                "headText"=>"Digital Library",
                "height"=>110,
                "subHeadText"=>"Bal Bharati Public School Ganga Ram Hospital Marg",
                "superHeadText"=>"",
                "headTop"=>"0px",
                "image"=>_DIR_GRAPH."official_graphics/BBPS_logo_blueGradient_med.png",
                "imageWidth"=>"119px",
                "imageSpace"=>"125px",
                "headSpace"=>"1px",
                "buttons"=>"0",
                "headerBgColor"=>"#adf",
                "headTextColor"=>"#4ad",
                "subTextColor"=>"#444",
                "superTextColor"=>"#444",
                "shortcutTextColor"=>"#def",
                "shortcutButtonColor"=>"#fa0",
                "shortcutText1"=>"shortcut1",
                "shortcutText2"=>"shortcut2",
                "shortcutText3"=>"shortcut3",
                "shortcutText4"=>"shortcut4",
                "displayNews"=>1,
                "newsSliderHeight"=>"40px"
            );
        }
        else{
            if(empty($this->HeadProperties["headText"])){
                $this->HeadProperties["headText"]="Digital Library";
            }
            if(empty($this->HeadProperties["height"])){
                $this->HeadProperties["height"]=110;
            }
            if(empty($this->HeadProperties["newsSliderHeight"])){
                $this->HeadProperties["newsSliderHeight"]="40px";
            }
            if(empty($this->HeadProperties["displayNews"])){
                $this->HeadProperties["displayNews"]=1;
            }
            if(empty($this->HeadProperties["subHeadText"])){
                $this->HeadProperties["subHeadText"]="Bal Bharati Public School Ganga Ram Hospital Marg";
            }
            if(empty($this->HeadProperties["headTop"])){
                $this->HeadProperties["headTop"]="0px";
            }
            if(empty($this->HeadProperties["imageWidth"])){
                $this->HeadProperties["imageWidth"]="119px";
            }
            if(empty($this->HeadProperties["superHeadText"])){
                $this->HeadProperties["superHeadText"]="";
            }
            if(empty($this->HeadProperties["image"])){
                $this->HeadProperties["image"]=_DIR_GRAPH."official_graphics/BBPS_logo_blueGradient_med.png";
            }
            if(empty($this->HeadProperties["headSpace"])){
                $this->HeadProperties["headSpace"]="1px";
            }
            if(empty($this->HeadProperties["imageSpace"])){
                $this->HeadProperties["imageSpace"]=(1.050 * $this->HeadProperties["imageWidth"])."px";
            }
            if(empty($this->HeadProperties["buttons"])){
                $this->HeadProperties["buttons"]=0;
            }
            if(empty($this->HeadProperties["headerBgColor"])){
                $this->HeadProperties["headerBgColor"]="#adf";
            }
            if(empty($this->HeadProperties["headTextColor"])){
                $this->HeadProperties["headTextColor"]="#4ad";
            }
            if(empty($this->HeadProperties["subTextColor"])){
                $this->HeadProperties["subTextColor"]="#444";
            }
            if(empty($this->HeadProperties["superTextColor"])){
                $this->HeadProperties["superTextColor"]="#444";
            }
            if(empty($this->HeadProperties["shortcutTextColor"])){
                $this->HeadProperties["shortcutTextColor"]="#def";
            }
            if(empty($this->HeadProperties["shortcutButtonColor"])){
                $this->HeadProperties["shortcutButtonColor"]="#fa0";
            }
            if(empty($this->HeadProperties["shortcutText1"])){
                $this->HeadProperties["shortcutText1"]="shortcut1";
            }
            if(empty($this->HeadProperties["shortcutText2"])){
                $this->HeadProperties["shortcutText2"]="shortcut2";
            }
            if(empty($this->HeadProperties["shortcutText3"])){
                $this->HeadProperties["shortcutText3"]="shortcut3";
            }
            if(empty($this->HeadProperties["shortcutText4"])){
                $this->HeadProperties["shortcutText4"]="shortcut4";
            }
            
        }
        if(empty($this->BodyProperties)){
            $this->BodyProperties = array(
                "bodyHTML"=>"",
                "bodyCSS"=>"",
                "bodyJSS"=>""
            );
        }
        else{
            if(empty($this->BodyProperties["bodyHTML"])){
                $this->BodyProperties["bodyHTML"]="";
            }
            if(empty($this->BodyProperties["bodyCSS"])){
                $this->BodyProperties["bodyCSS"]="";
            }
            if(empty($this->BodyProperties["bodyJS"])){
                $this->BodyProperties["bodyJS"]="";
            }
            
        }
        if(empty($this->FooterProperties)){
            $this->FooterProperties = array(
                "footerBgColor"=>$this->HeadProperties["headerBgColor"],
                "footerText"=>"",
                "footerTextColor"=>"#777",
                "footerNaviTextColor"=>"rgb(51,86,178)",
                "footerListTextColor"=>"#679"
                
            );
        }
        else{
            if(empty($this->FooterProperties["footerBgColor"])){
                $this->FooterProperties["footerBgColor"]=$this->HeadProperties["headerBgColor"];
            }
            if(empty($this->FooterProperties["footerText"])){
                $this->FooterProperties["footerText"]="";
            }
            if(empty($this->FooterProperties["footerTextColor"])){
                $this->FooterProperties["footerTextColor"]="#777";
            }
            if(empty($this->FooterProperties["footerNaviTextColor"])){
                $this->FooterProperties["footerNaviTextColor"]="rgb(51,86,178)";
            }
            if(empty($this->FooterProperties["footerListTextColor"])){
                $this->FooterProperties["footerListTextColor"]="#639";
            }
            
        }
        
        $this->print_meta();
        $this->print_page();
        
        if($end){
        $this->print_end();
        }
    }//function
    
public function print_meta(){echo '<!DOCTYPE '.$this->PageProperties["doctype"].'><html lang="'.$this->PageProperties["baselan"].'">';echo '<head>';echo '<title>'.$this->PageProperties["title"].'</title>';echo '<meta charset="'.$this->PageProperties["charset"].'"><meta name="keywords" content="'.$this->PageProperties["keywords"].'"><meta name="description" content="'.$this->PageProperties["description"].'">';echo '<link rel="stylesheet" type="text/css" href="none_style.css"><link rel="stylesheet" type="text/css" href="fonts.css">';echo '<script src="jquery/jquery-2.1.3.js"></script><script src="gsap/TweenMax.min.js"></script>';echo '</head>';echo '<body>';}//function
    
public function print_end(){
    echo '
        </div>
        
        <div class="pageFooter">
            <h1>
                <a href="#">tour</a>
                <a href="#">help</a>
                <a href="#">blog</a>
                <a href="#">legal</a>
                <a href="#">privacy policy</a>
                <a href="#">mobile</a>
                <a href="#">contact us</a>
                <a href="#">feedback</a>
            </h1>
            <h2>
                <ul>
                    <a href="#">DIGITAL LIBRARY</a>
                    <li><a href="#">Books</a></li>
                    <li><a href="#">Reviews</a></li>
                    <li><a href="#">SoftCopy</a></li>
                    <li><a href="#">HardCopy</a></li>
                    <li><a href="#">Report</a></li>
                </ul>
                <ul>
                    <a href="#">CBSE</a>
                    <li><a href="#">Circular</a></li>
                    <li><a href="#">Cbse Academic</a></li>
                    <li><a href="#">Sample Papers</a></li>
                    <li><a href="#">Old Question Papers</a></li>
                    <li><a href="#">News</a></li>
                    <li><a href="#">Results</a></li>
                </ul>
                <ul>
                    <a href="#">BBPSGRH SITE</a>
                    <li><a href="#">School Events</a></li>
                    <li><a href="#">Circulars</a></li>
                    <li><a href="#">Blog</a></li>
                    <li><a href="#">Examination</a></li>
                    <li><a href="#">Book List</a></li>
                    <li><a href="#">Assignments</a></li>
                    <li><a href="#">Syllabus</a></li>
                </ul>
                <ul>
                    <a href="#">SUPPORT</a>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Contact Us</a></li>
                    <li><a href="#">Report Abuse</a></li>
                    <li><a href="#">Report Material</a></li>
                    <li><a href="#">HelpDesk</a></li>
                    <li><a href="#">Moderators</a></li>
                </ul>
            </h2>
            <h3>Bal Bharati Public School Logo © 2015: used with permission under non profit terms. 
            '.$this->FooterProperties["footerText"].'</h3>
            
            <div class="arrow_div">
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
            </div>
        </div>
       
    </div>
</div>
<script name="HeadNewsBarScript">
var allNewsLiTags = document.getElementsByClassName("newsElem");
var activeNewsLiTag = 1;
var totalNewsLiTags = allNewsLiTags.length;
var Newsarrowheads = document.getElementsByClassName("arwhead");
var activeNewsLiTagFactor=1;
function newsArrowClickFunc(clickontag){
    if (clickontag==1){
        if(activeNewsLiTag>=1 && activeNewsLiTag<totalNewsLiTags){
            TweenMax.to(allNewsLiTags[activeNewsLiTag-1], .75, {right:"0", display:"none", left:"-1500px"});
            TweenMax.to(allNewsLiTags[++activeNewsLiTag-1], .75, {right:"0", display:"inline-block", left:"0"});
            
            
        }
        else if(activeNewsLiTag==totalNewsLiTags){activeNewsLiTagFactor=0;}
    }
    else if (clickontag==2){
        if(activeNewsLiTag<=totalNewsLiTags && activeNewsLiTag>1){
            TweenMax.to(allNewsLiTags[activeNewsLiTag-1], .75, {right:"-1500", display:"none", left:"0"});
            TweenMax.to(allNewsLiTags[--activeNewsLiTag-1], .75, {right:"0", display:"inline-block", left:"0"});
        }
        else if(activeNewsLiTag==1){activeNewsLiTagFactor=1;}
    }
}
setInterval(function(){
if(activeNewsLiTagFactor){
Newsarrowheads[0].click();
}
else
{
Newsarrowheads[1].click();
}
},3000);
</script>
<script>
'.$this->BodyProperties["bodyJSS"].'
</script>
</body>
</html>
';
}

public function print_page(){
echo '

<style>
.bgBody{
background: '.$this->PageProperties["bg"].';
position:relative;
min-height:100%;
z-index:-1;
padding: 10%;
padding-top: 50px;
padding-bottom: 30px;
z-index:0;



}
.bgBody .bgPage{
z-index:0;
background: '.$this->PageProperties["pageBg"].';
display:block;
width:100%;
min-height:'.$this->PageProperties["minHeight"].';
border-radius: '.$this->PageProperties["pageBorderRadius"].';
position:relative;
margin-right:0px;
overflow: hidden;
z-index:2;
}
.bgPage .pageHeader{
position:relative;
z-index:20;
width:100%;
height:'.$this->HeadProperties["height"].'px;
background:'.$this->HeadProperties["headerBgColor"].';
}
.bgPage .pageHeader h1{
font-family: ttf_3;
font-size: 42pt;
color: '.$this->HeadProperties["headTextColor"].';
position:absolute;
top:24px;
margin-left:3px;

}
.bgPage .pageHeader h2{
font-family: ttf_3;
font-size: 8pt;
color: '.$this->HeadProperties["superTextColor"].';
position:absolute;
top:16px;
margin-left:8px;

}
.bgPage .pageHeader h3{
font-family: ttf_3;
font-size: 11pt;
color: '.$this->HeadProperties["subTextColor"].';
position:absolute;
top:90px;
margin-left:7px;
}

.pageHeader .arrow_div .arrow #inner{
transform: rotate(45deg);
-ms-transform: rotate(45deg);
-webkit-transform: rotate(45deg);
-o-transform: rotate(45deg);
-moz-transform: rotate(45deg); 
background-color:'.$this->HeadProperties["headerBgColor"].';
width:60px;
height:60px;
top: 20px;
left: -50px;
position:relative;
-moz-border-radius: 20px;
border-radius: 5px;
box-shadow:0px 2px 1px 0px rgba(0,0,0,0.3);
}

.pageHeader .arrow_div .arrow #outer{
position: absolute;
width: 60px;
height: 120px;    
overflow: hidden;    
-webkit-transform: rotate(90deg);
}
.pageHeader .arrow_div .arrow{
position:relative;
display:inline-block;
top:'.($this->HeadProperties["height"]-44).'px;
left:-20px;
width:39px;
}

.pageHeader .arrow_div{
width:100%;
position:absolute;
height:'.$this->HeadProperties["height"].'px;
white-space: nowrap;
z-index:-1;
}

.bgPage .pageFooter{
position:absolute;
bottom:0px;
width:100%;
height:220px;
background:'.$this->FooterProperties["footerBgColor"].';
z-index:1;
}
.bgPage .pageFooter h1{
position:absolute;
top:12px;
left:8px;
white-space: nowrap;
z-index:3;
}
.bgPage .pageFooter h1 a{
text-decoration: none;
color:'.$this->FooterProperties["footerNaviTextColor"].';
margin-left:8px;
font-size:14px;
font-family:ttf_3;

}
.bgPage .pageFooter h2{
position:absolute;
top:40px;
width:100%;
text-align: center;
z-index:3;
}
.bgPage .pageFooter h2 ul{
position:relative;
display: inline-block;
vertical-align: top;
margin-left:30px;
margin-right:30px;
text-align:left;
}
.bgPage .pageFooter h2 ul a{
color:'.$this->FooterProperties["footerListTextColor"].';
font-size:12px;
font-family:ttf_4;
text-decoration:none;

}
.bgPage .pageFooter h2 ul li a{
font-size: 12px;
font-family:ttf_3;
}
.bgPage .pageFooter h2 ul li{
margin-top:2px;
}
.bgPage .pageFooter h3{
position: absolute;
left:20px;
top:200px;
font-family:ttf_3;
font-size:10px;
color: '.$this->FooterProperties["footerTextColor"].';
}

.pageFooter .arrow_div .arrow #inner{
transform: rotate(45deg);
-ms-transform: rotate(45deg);
-webkit-transform: rotate(45deg);
-o-transform: rotate(45deg);
-moz-transform: rotate(45deg); 
background-color:'.$this->FooterProperties["footerBgColor"].';
width:60px;
height:60px;
top: 20px;
left: -50px;
position:relative;
-moz-border-radius: 20px;
border-radius: 5px;
box-shadow: -2px -0px 1px rgba(0,0,0,0.3);
}

.pageFooter .arrow_div .arrow #outer{
position: absolute;
width: 60px;
height: 120px;    
overflow: hidden;    
-webkit-transform: rotate(-90deg);
}
.pageFooter .arrow_div .arrow{
position:relative;
display:inline-block;
bottom:103px;
left:-20px;
width:39px;
}
.pageFooter .arrow_div{
width:100%;
position:absolute;
height:200px;
white-space: nowrap;
z-index:2;

}
.bgPage .pageHeader .HeaderButtons{

position: absolute;
width:250px;
height:110px;
right:15px;
top:20px;
text-align:right;
}
.bgPage .pageHeader .HeaderButtons .hb{
display: inline-block;
text-align:left;

width:110px;
height:110px;
margin-top:12px;
}
.bgPage .pageHeader .HeaderButtons .hb div{
border:solid thin;
margin:5px;
margin-bottom:10px;
width:100px;
height:23px;
border-radius: 3px;
text-align:center;
padding-top:7px;
cursor:pointer;
font-family:ttf_3;
font-size:13px;
box-shadow:0px 1px 1px 0px rgba(0,0,0,0.4);
color:'.$this->HeadProperties["shortcutTextColor"].';
background:'.$this->HeadProperties["shortcutButtonColor"].';
}
.bgPage .pageHeader .imgback{
position:relative;
display: inline-block;
height:38px;
width:75px;
}
.bgPage .pageHeader .img{
position:absolute;
z-index:2;
top:1px;
left:1px;
bottom:1px;
width:'.$this->HeadProperties["imageWidth"].';
background: url('.$this->HeadProperties["image"].') no-repeat;
background-size: cover;
}

'.$this->BodyProperties["bodyCSS"].'

.headings_page{
position:absolute;
top:0;
left:0;
right:0;
bottom:0;
margin-left:'.$this->HeadProperties["headSpace"].';
}
.texts_page{
position:absolute;
top:'.$this->HeadProperties["headTop"].';
left:0;
right:0;
bottom:0;
margin-left:'.$this->HeadProperties["imageSpace"].';
}

.pageHeader .NewsSlider{
position: absolute;
bottom:10px;
height:'.$this->HeadProperties["newsSliderHeight"].';
left:'.$this->HeadProperties["imageSpace"].';
right:17px;
overflow: hidden;
z-index:3;
display:';
if($this->HeadProperties["displayNews"]){
echo "block";
}
else{
echo "none";
}
echo ';
}
.pageHeader .NewsSlider .arwhead{
position:absolute;
top:0;
bottom:0;
width: '.$this->HeadProperties["newsSliderHeight"].';
border-radius:50%;
z-index:2;

}
.pageHeader .NewsSlider .arrowheadRight{
background : url("graphics/interface_graphics/icons/right.png") center no-repeat;
background-size: contain;
right:0;


}
.pageHeader .NewsSlider .arrowheadLeft{
background : url("graphics/interface_graphics/icons/left.png") center no-repeat;
background-size: contain;
left:0;
}
.pageHeader .NewsSlider ul{
position: absolute;
top:1px;
left:'.$this->HeadProperties["newsSliderHeight"].';
right:'.$this->HeadProperties["newsSliderHeight"].';
margin-left:5px;
margin-right:5px;
bottom:1px;
z-index:1;
white-space: nowrap;
text-align: center;
}
.pageHeader .NewsSlider ul li{
display: inline-block;
position: absolute;
top:0;
left:0;
right:0;
bottom:0;
white-space: normal;
font-size:20px;
line-height:35px;
font-family: ttf_9;
color:#444;
}
.pageHeader .NewsSlider ul li:nth-of-type(1){
right:0;
display:inline-block;
left:0;
}
.pageHeader .NewsSlider ul li:nth-of-type(2){
right:-1500px;
display:none;
left:0;
}
.pageHeader .NewsSlider ul li:nth-of-type(3){
right:-1500px;
display:none;
left:0;
}
.pageHeader .NewsSlider ul li:nth-of-type(4){
right:-1500px;
display:none;
left:0;
}
.pageHeader .NewsSlider ul li:nth-of-type(5){
right:-1500px;
display:none;
left:0;
}
.pageHeader .NewsSlider ul li:nth-of-type(6){
right:-1500px;
display:none;
left:0;
}
.pageHeader .NewsSlider ul li:nth-of-type(7){
right:-1500px;
display:none;
left:0;
}
.pageHeader .NewsSlider ul li:nth-of-type(8){
right:-1500px;
display:none;
left:0;
}
.pageHeader .Navi_buttons{
z-index:3;
position: absolute;
bottom: '.$this->HeadProperties["newsSliderHeight"].';
margin-bottom: 50px;
height: 25px;
left: '.$this->HeadProperties["imageSpace"].';
right: 17px;
}
.pageHeader .Navi_buttons ul{
position: absolute; 
top:0;
right:0;
left:0;
bottom:0;
}
.pageHeader .Navi_buttons ul li{
position: relative;
display: inline-block;
border: solid thin;
border-radius:30px;
color:#eee; 
margin-top:3px;
box-shadow: 0px 1px 1px 0px rgba(0,0,0,0.3);
cursor: pointer;
padding:3px;
}
.pageHeader .Navi_buttons ul li a{
font-size: 18px;
font-family: ttf_9;
color:#eee; 
text-decoration:none;
position: relative;
padding:0px;
padding-left:20px;
padding-right:5px;
}

.pageHeader .Navi_buttons ul li .icon{
position: absolute;
top:1px;
left:1px;
bottom:1px;
border: solid thin;
width:16px;
border-radius: 50%;
color:#eee; 
background-size: 12px 12px;
z-index:3;
}
.pageHeader .Navi_buttons ul li a .bgicon{
position: absolute;
top:1px;
left:1px;
bottom:1px;
border: solid thin;
width:16px;
border-radius: 50%;
background: linear-gradient(to bottom, rgba(255,255,255,1) 0%,rgba(243,243,243,1) 50%,rgba(237,237,237,1) 51%,rgba(255,255,255,1) 100%);
z-index:2;

}
.pageHeader .Navi_buttons ul li a .fwdicon{
position: absolute;
top:1px;
left:1px;
bottom:1px;
border: solid thin;
width:16px;
border-radius: 50%;
background:url(graphics/mics_graphics/simple_bubble.png) center no-repeat;
background-size: cover;
z-index:4;
}
.pageHeader .Navi_buttons ul li:nth-of-type(1){
background:linear-gradient(to bottom, rgba(255,168,76,1) 0%,rgba(255,123,13,1) 100%);}
.pageHeader .Navi_buttons ul li:nth-of-type(2){
background:linear-gradient(to bottom, rgba(255,168,76,1) 0%,rgba(255,123,13,1) 100%);}
.pageHeader .Navi_buttons ul li:nth-of-type(3){
background:linear-gradient(to bottom, rgba(255,168,76,1) 0%,rgba(255,123,13,1) 100%);}
.pageHeader .Navi_buttons ul li:nth-of-type(4){
background:linear-gradient(to bottom, rgba(255,168,76,1) 0%,rgba(255,123,13,1) 100%);}
.pageHeader .Navi_buttons ul li:nth-of-type(5){
background:linear-gradient(to bottom, rgba(255,168,76,1) 0%,rgba(255,123,13,1) 100%);}
.pageHeader .Navi_buttons ul li:nth-of-type(6){
background:linear-gradient(to bottom, rgba(255,168,76,1) 0%,rgba(255,123,13,1) 100%);}
.pageHeader .Navi_buttons ul li:nth-of-type(7){
background:linear-gradient(to bottom, rgba(255,168,76,1) 0%,rgba(255,123,13,1) 100%);}

.pageHeader .Navi_buttons ul li .icon:nth-of-type(1){
background: url(graphics/interface_graphics/icons/home.png) center no-repeat;
background-size: 12px 12px;
}
.pageHeader .Navi_buttons ul li .icon:nth-of-type(2){
background:url(graphics/interface_graphics/icons/home.png) center no-repeat;
background-size: 12px 12px;
}
.pageHeader .Navi_buttons ul li .icon:nth-of-type(3){
background:url(graphics/interface_graphics/icons/home.png) center no-repeat;
background-size: 12px 12px;
}
.pageHeader .Navi_buttons ul li .icon:nth-of-type(4){
background:url(graphics/interface_graphics/icons/home.png) center no-repeat;
background-size: 12px 12px;
}
.pageHeader .Navi_buttons ul li .icon:nth-of-type(5){
background:url(graphics/interface_graphics/icons/home.png) center no-repeat;
background-size: 12px 12px;
}
.pageHeader .Navi_buttons ul li .icon:nth-of-type(6){
background:url(graphics/interface_graphics/icons/home.png) center no-repeat;
background-size: 12px 12px;
}
.pageHeader .Navi_buttons ul li .icon:nth-of-type(7){
background:url(graphics/interface_graphics/icons/home.png) center no-repeat;
background-size: 12px 12px;
}
.infoUserDatabaseTab{
    position: absolute;
    top:0;
    right:0;
    z-index: 20;
    text-align: right;
    
    
}
.infoUserDatabaseTab .headingUserData{
    
    margin-top:3px;
    margin-right:3px;
    cursor: pointer;
    
}
.infoUserDatabaseTab .headingUserData .usernameTab{
    border: solid thin;
    border-radius: 30px;
    padding:2px;
    padding-right:20px;
    display: inline-block;
    font-family: ttf_9;
    font-size:16px;
    position:relative;
    
}
.infoUserDatabaseTab .headingUserData .usernameTab .dropdown{
    position: absolute;
    border:solid thin;
    display: inline-block;
    border-radius: 30px;
    height: 14px;
    width:14px;
    right:2px;
    
    
}
.infoUserDatabaseTab .headingUserData .logout{
    border: solid thin;
    border-radius: 30px;
    position:relative;
    bottom:0;
    right:0;top:0;
    vertical-align:bottom;
    margin-left:2px;
    display: inline-block;
    height:20px;
    width:20px;
    cursor: pointer;
}
.infoUserDatabaseTab .infoUserDatabaseDropDown{
    border-radius:5px;
    text-align:left;
    position:absolute;
    z-index:5;
    top:45px;
    right:30px;
    width:210px;
    background:#fff;
    padding:10px 20px 10px 20px;
    box-shadow: 0px 1px 5px rgba(0,0,0,0.2);
    
    display:none;
    
    
}
.infoUserDatabaseTab .infoUserDatabaseDropDown .infoUserDatabaseDropdownPosarrow .arrow #inner{
transform: rotate(45deg);
-ms-transform: rotate(45deg);
-webkit-transform: rotate(45deg);
-o-transform: rotate(45deg);
-moz-transform: rotate(45deg); 
background-color:#fff;
width:55px;
height:55px;
top: 0px;
left: -50px;
position:relative;
-moz-border-radius: 5px;
border-radius: 5px;
box-shadow: 0px 0px 5px rgba(0,0,0,0.2);
}

.infoUserDatabaseTab .infoUserDatabaseDropDown .infoUserDatabaseDropdownPosarrow .arrow #outer{
position: absolute;
width: 60px;
height: 60px;    
overflow: hidden;    
-webkit-transform: rotate(-90deg);
}
.pageFooter .arrow_div .arrow{
}
.infoUserDatabaseTab .infoUserDatabaseDropDown .infoUserDatabaseDropdownPosarrow{
width:60px;
position:absolute;
height:60px;
top:-60px;
right:10px;

white-space: nowrap;
z-index:2;
}
.infoUserDatabaseTab .infoUserDatabaseDropDown .infoUserDatabaseDropDownUltag{

}
.infoUserDatabaseTab .infoUserDatabaseDropDown .infoUserDatabaseDropDownUltag li{
padding:10px;
border-bottom:solid thin;
font-family: ttf_3;
font-size: 20px;
color:#666;
border-color:rgba(100,100,100,0.3);
}
.infoUserDatabaseTab .infoUserDatabaseDropDown .infoUserDatabaseDropDownUltag li:last-of-type{
    border:none;
}
.infoUserDatabaseTab .infoUserDatabaseDropDown .infoUserDatabaseDropDownUltag .infoUserDropdownendTag{

position:absolute;
z-index:6;
bottom:0;
left:0;
right:0;
height:10px;
border-radius:0px 0px 5px 5px;
background:#def;
}
</style>




<div class="bgBody">
    
    <div class="bgPage">
        <div class="pageHeader">
        
            <div class="infoUserDatabaseTab">
                <div class="headingUserData">
                    <div class="usernameTab">Shaurya Singh<div class="dropdown"></div></div>
                    <div class="logout"></div>
                </div>
            
            <div class="infoUserDatabaseDropDown">
            <div class="infoUserDatabaseDropdownPosarrow"><div class="arrow"><div id="outer"><div id="inner"></div></div></div></div>
                <ul class="infoUserDatabaseDropDownUltag">
                    <li>Dashboard</li>
                    <li>Settings</li>
                    <li>Help</li>
                    <li>Report Problems</li>
                    <li>Log Out</li>
                    <div class="infoUserDropdownendTag"></div>
                </ul>
            </div>
        </div>
        <div class="Navi_buttons">
        <ul>
            <li class="newsScrllerClass"><a href="#"><div class="bgicon"></div><div class="icon"></div><div class="fwdicon"></div>Home</a></li>
            <li class="newsScrllerClass"><a href="#"><div class="bgicon"></div><div class="icon"></div><div class="fwdicon"></div>Books</a></li>
            <li class="newsScrllerClass"><a href="NCERT_Copy/ncert.html"><div class="bgicon"></div><div class="icon"></div><div class="fwdicon"></div>Study Material</a></li>
            <li class="newsScrllerClass"><a href="#"><div class="bgicon"></div><div class="icon"></div><div class="fwdicon"></div>School Blog</a></li>
            <li class="newsScrllerClass"><a href="#"><div class="bgicon"></div><div class="icon"></div><div class="fwdicon"></div>News</a></li>
            <li class="newsScrllerClass"><a href="#"><div class="bgicon"></div><div class="icon"></div><div class="fwdicon"></div>Circulars</a></li>
            <li class="newsScrllerClass"><a href="#"><div class="bgicon"></div><div class="icon"></div><div class="fwdicon"></div>Mics.</a></li>
        </ul>
        </div>
                <div class="NewsSlider">
                <div class="arrowheadRight arwhead" onclick="newsArrowClickFunc(1)"></div>
            
                    <ul>
                        <li class="newsElem">Welcome to BBPSGRH Digital Library!</li>
                        <li class="newsElem">A new Sherlock Homes Added: A Study in Scarlet</li>
                        <li class="newsElem">A new Charles Dickens Added: Pickwick Papers</li>
                        <li class="newsElem">New Biography: Khaled Hosseini</li>
                        <li class="newsElem">A New Jhon Steinbeck: East of Eden</li>
                        <li class="newsElem">Question papers XII(2014-15) BOARDS + Solutions: Added</li>
                        <li class="newsElem">Question papers XI(2014-15) + Solutions: Added</li>
                        <li class="newsElem">Question papers X(2014-15): Added</li>
                    </ul>
                    
                <div class="arrowheadLeft arwhead" onclick="newsArrowClickFunc(2)"></div>
                </div>
        
        <div class="headings_page">
            
        <div class="img"></div>
        <div class="imgback"></div><div class="texts_page">
            <h1>'.$this->HeadProperties["headText"].'</h1>
            <h2>'.$this->HeadProperties["superHeadText"].'</h2>
            <h3>'.$this->HeadProperties["subHeadText"].'</h3></div>
            </div>
            <div class="HeaderButtons">';
            if($this->HeadProperties["buttons"]==0){}
        elseif($this->HeadProperties["buttons"]==1){
            echo '
                <div class="hb_left hb">
                    <div>'.$this->HeadProperties["shortcutText3"].'</div>
                </div>
                ';
        }
        elseif($this->HeadProperties["buttons"]==2){
            echo '<div class="hb_left hb">
                    <div>'.$this->HeadProperties["shortcutText3"].'</div>
                    <div>'.$this->HeadProperties["shortcutText4"].'</div>
                </div>';
        }
        elseif($this->HeadProperties["buttons"]==3){
        echo '
            <div class="hb_right hb">
                    <div>'.$this->HeadProperties["shortcutText1"].'</div>
                </div>
                <div class="hb_left hb">
                    <div>'.$this->HeadProperties["shortcutText3"].'</div>
                    <div>'.$this->HeadProperties["shortcutText4"].'</div>
                </div>
        ';
        }
        elseif($this->HeadProperties["buttons"]==4){
            echo '
            <div class="hb_right hb">
                    <div>'.$this->HeadProperties["shortcutText1"].'</div>
                    <div>'.$this->HeadProperties["shortcutText2"].'</div>
                </div>
                <div class="hb_left hb">
                    <div>'.$this->HeadProperties["shortcutText3"].'</div>
                    <div>'.$this->HeadProperties["shortcutText4"].'</div>
                </div>
            ';
        }
                
            
  echo '</div>
            
            <div class="arrow_div">
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
                <div class="arrow"><div id="outer"><div id="inner"></div></div></div>
            </div>
            
            
            
            
        </div>
        
        <div class="pageBody">
        
        '.$this->BodyProperties["bodyHTML"];
    }
}//class

class gw_loginpageTemplate{
    
}

class gw_ncerpageTemplate{
    
}

?>

