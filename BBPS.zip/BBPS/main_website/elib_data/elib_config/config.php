<?php
 /*
 * Config.php version: 2.0 
 * Developed by Shaurya Singh
*/

$db_MYSQL_SERVER = 'localhost'; //MySql host address
$db_MYSQL_USER= 'root'; //db user
$db_MYSQL_Pass= 'Quvlly18&fumi_gating'; //db pass

define(DB_BBPS_USER, "BBPS_user_database");
define(DB_BBPS_STUDY, "BBPS_study_database");
define(DB_BBPS_LIB, "BBPS_library_database");
define(DB_BBPS_BLOG, "BBPS_blog_database");

$db_CHARSET= "utf8"; //charset of database for communication

function clean_input($data){
    $data = htmlspecialchars($data);
    $data = trim($data);
    $data = stripslashes($data);
    return $data;
}
function _sec1_($token){
    return $token = hash('ripemd128', $token);
}

$onloginverifi_subject = 'BBPS Elibrary Logged In';
$onloginverifi_msg = 'You Logged in at BBPS Elibrary at'.time().'.\n Client side Details: \n'."\tClient Ip: ".($_SERVER['REMOTE_ADDR'])."\n\tClient Useragent: ".($_SERVER['HTTP_USER_AGENT'])."\n\tSession Id: ".(session_id())."\nIf it were not you reset your password and contact Helpdesk.";

$signupverify_subj = 'BBPS Elibrary Sign Up verification';
function signupverify_msg($ver_token){
    return '
    Thank You for sigining up at BBPS Elibrary.\n
    This is the verification Email for your Account.\n
    Fill this Serial on the Login Page: '.$ver_token.'.\n
    If You didn\'t Signed up at BBPS elibrary, Kindly ignore this email.
    ';
}
   
?>