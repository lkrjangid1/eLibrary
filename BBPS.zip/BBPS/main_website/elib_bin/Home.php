<?php
include "../elib_data/elib_depend/glasswindow/class_glasswindow.php";
$obj = new gw_mainpageTemplate;
$obj->HeadProperties=array("headText"=>"Digital Library", "height"=>230, "buttons"=>4, "imageWidth"=>"251px", "buttons"=>4);
$obj->PageProperties["minHeight"]="2000px";
$obj->to(0);
?>
<style>
    .showcaseHomeModule{
        position:relative;
        height:700px;
        display:block;
        width:100%;
        top:-10px;
    }
    .showcaseHomeModule .ShowcaseDisplayCaptionButtons{
        position: absolute;
        bottom:0;
        left:0;
        right:0;
        height:50px;
        background:linear-gradient(to bottom, rgba(255,255,255,1) 0%,rgba(229,229,229,1) 100%); 
        border:solid 2px;
        border-left:0;
        border-right:0;
        border-color: #aaa;
        z-index:6;
        white-space: nowrap;
        
    }
    .showcaseHomeModule .ShowcaseDisplayCaptionButtons .shwHomeDCbut{
        display: inline-block;
        
        text-align: center;
        width:16%;
        vertical-align:middle;
        position:relative;
        top:0px;
        left:0;
        border-right: solid thin rgba(100,100,100,0.4);
        height:40px;
        padding:5px;
        
        white-space: normal;
        
    }
    .showcaseHomeModule .ShowcaseDisplayCaptionButtons .arrow_ShwhomeDcbut .arrow #inner{
transform: rotate(45deg);
-ms-transform: rotate(45deg);
-webkit-transform: rotate(45deg);
-o-transform: rotate(45deg);
-moz-transform: rotate(45deg); 
background-color:#fff;
width:58px;
height:58px;
top: 5px;
left: -50px;
position:relative;
-moz-border-radius: 20px;
border-radius: 5px;
border:solid 2px #aaa;
}

.showcaseHomeModule .ShowcaseDisplayCaptionButtons .arrow_ShwhomeDcbut .arrow #outer{
position: absolute;
width: 30px;
height: 60px; 
overflow: hidden; 
-webkit-transform: rotate(-90deg);
}
.showcaseHomeModule .ShowcaseDisplayCaptionButtons .arrow_ShwhomeDcbut .arrow{
position:relative;
display:inline-block;
top:-30px;
width:40px;
}

.showcaseHomeModule .ShowcaseDisplayCaptionButtons .arrow_ShwhomeDcbut{

position:absolute;
    top:-20px;
    left:7%;

white-space: nowrap;
z-index:10;
    height:20px;
    overflow:hidden;
}
    .showcaseHomeModule .ShowcaseDisplayCaptionButtons .shwHomeDCbut a{
        text-decoration: none;
        color:#444;
        font-family: ttf_3;
        display:inline-block;
        width:100%;
        
        position:relative;
        vertical-align:middle;
    
    }
    .showcaseHomeModule .ShowcaseDisplayplanes{
        position: absolute;
        bottom:50px;
        left:0;
        right:0;
        top:0;
    }
    .showcaseHomeModule .Navigationbuttons{
        position: absolute;
        z-index:5;
        top:310px;
        height:50px;
        width:50px;
        border-radius:50%;
    }
    .showcaseHomeModule .rightArrowButton{
        right:60px;
        background: url(graphics/interface_graphics/icons/play_right.png) center no-repeat;
        background-size: cover;
        
    }
    .showcaseHomeModule .leftArrowButton{
        left:60px;
        background: url(graphics/interface_graphics/icons/play_left.png) center no-repeat;
        background-size: cover;
    }
    .showcaseHomeModule .shwcaseHomeDispcurtains{
        position: absolute;
        z-index:4;
        top:0;
        bottom:50px;
        width:200px;
        background: url(graphics/mics_graphics/rightcurtain.png) no-repeat;
        background-size: cover;
    }
    .showcaseHomeModule .shwcaseHomeDispcurtains:nth-of-type(1){
        left:0;
        transform: rotateX(180deg);
        -ms-transform: rotateX(45deg);
        -webkit-transform: rotateY(180deg);
        -o-transform: rotateX(45deg);
        -moz-transform: rotateX(45deg); 
    }
    .showcaseHomeModule .shwcaseHomeDispcurtains:nth-of-type(2){
        right:0;
    }
    
</style>

<div class="showcaseHomeModule">
    <div class="shwcaseHomeDispcurtains"></div>
    <div class="shwcaseHomeDispcurtains"></div>
    
    <div class="Navigationbuttons rightArrowButton" onclick="showcaseHomeDisp_EventChange_function(-1)"></div>
    <div class="Navigationbuttons leftArrowButton" onclick="showcaseHomeDisp_EventChange_function(-2)"></div>
    
    <div class="ShowcaseDisplayplanes">
        <div class="shwHomeDipPlane"></div>
        <div class="shwHomeDipPlane"></div>
        <div class="shwHomeDipPlane"></div>
        <div class="shwHomeDipPlane"></div>
        <div class="shwHomeDipPlane"></div>
        <div class="shwHomeDipPlane"></div>
    </div>
    <div class="ShowcaseDisplayCaptionButtons">
        <div class="arrow_ShwhomeDcbut"><div class="arrow"><div id="outer"><div id="inner"></div></div></div></div>
        <div class="colortab_ShwhomeDcbut"></div>
        
        <div class="shwHomeDCbut" onmouseover="showcaseHomeDisp_EventChange_function(1)">
            <a class="shwHomeDCbutAtag" href="#">Sherlock Homes by Sir Arthur Conan Doyle</a>
        </div><!--
        --><div class="shwHomeDCbut" onmouseover="showcaseHomeDisp_EventChange_function(2)">
            <a class="shwHomeDCbutAtag" href="#">Shakespeare's Sonnets</a>
        </div><!--
        --><div class="shwHomeDCbut" onmouseover="showcaseHomeDisp_EventChange_function(3)">
            <a class="shwHomeDCbutAtag" href="#">Diary of a Wimpy Kid: The Long haul</a>
        </div><!--
        --><div class="shwHomeDCbut" onmouseover="showcaseHomeDisp_EventChange_function(4)">
            <a class="shwHomeDCbutAtag" href="#">Steve Jobs by Walter Isaacson</a>
        </div><!--
        --><div class="shwHomeDCbut" onmouseover="showcaseHomeDisp_EventChange_function(5)">
            <a class="shwHomeDCbutAtag" href="#">X86 Assembly Language Programming</a>
        </div><!--
        --><div class="shwHomeDCbut" onmouseover="showcaseHomeDisp_EventChange_function(6)">
            <a class="shwHomeDCbutAtag" href="#">Kite Runner By Khaled Hosseini</a>
        </div>
        
    </div>
</div> <!--End of showcase module-->
<script>
var activeShowcaseDispPlane=1;
var shwHomeDCbut = document.getElementsByClassName("shwHomeDCbut");
var arrow_ShwhomeDcbut = document.getElementsByClassName("arrow_ShwhomeDcbut")[0];
function showcaseHomeDisp_EventChange_function(obj){
    if(obj<0){//buttons
    }
    if(obj>0){//caption
        var lengthfromleft = (shwHomeDCbut[obj-1].width*obj - shwHomeDCbut[obj-1].width/2 -20);
        TweenMax.to(arrow_ShwhomeDcbut,0.5,{left:lengthfromleft});
    }
}
    
</script>
<?php
$obj->print_end();
?>
